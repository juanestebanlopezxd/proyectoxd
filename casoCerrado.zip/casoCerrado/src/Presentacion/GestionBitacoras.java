/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;


import Modelo.Bitacora;
import Persistencia.GestionBitacora;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Antony
 */
public class GestionBitacoras extends javax.swing.JFrame {
    
    GestionBitacora gestionBitacora = new GestionBitacora();
    public ArrayList<Bitacora> bitacoras;
    int pos = 0;
    String ruta;
    DefaultTableModel modelo;
    /**
     * Creates new form Bitacora
     */
    
    public GestionBitacoras() {
        initComponents();
        cargarFechaInput();
        bitacoras = new ArrayList<>();
    }
    
    public void ponerTitulo(String titulo){
        lblNombreCaso.setText(titulo);
    }
    
    
    private void ActualizarTabla(){
        String[] fila;
        modelo = new DefaultTableModel();
        String[] columnas = {"Fecha","Observacion","Anotacion","",""};
        modelo.setColumnIdentifiers(columnas);
        for(Bitacora bitacora:bitacoras){
            fila = new String[columnas.length];
            fila[0] = ""+bitacora.getFechaDeRegistro();
            fila[1] = bitacora.getObservacion();
            fila[2] = bitacora.getAnotaciones();
            fila[3] = "Editar";
            fila[4] = "Eliminar";
            modelo.addRow(fila);
        }
        tablaBitacora.setModel(modelo);
    }
    
    private void Limpiar(){
        
        
        txtAnotacion.setText("");
        txtObservacion.setText("");
        
        
        btnCrear.setEnabled(true);
        btnActualizar.setEnabled(false);
    }
    
    private void Seleccion(){
        if(tablaBitacora.getSelectedColumn()==4){
             if (JOptionPane.showConfirmDialog(rootPane, "¿Seguro que desea eliminar?")==0) {
                this.bitacoras.remove(tablaBitacora.getSelectedRow());
                Limpiar();
                ActualizarTabla();
            }
        }else if(tablaBitacora.getSelectedColumn()==3){
             if (JOptionPane.showConfirmDialog(rootPane, "¿Seguro que desea editar?")==0) {
                editar(tablaBitacora.getSelectedRow());
                ActualizarTabla();
            }
        }
    }
    
    private void editar(int pos){
        Bitacora bitacora = bitacoras.get(pos);
        txtFecha.setEnabled(false);
        
        txtFecha.setText(""+bitacora.getFechaDeRegistro());
        txtAnotacion.setText(bitacora.getAnotaciones());
        txtObservacion.setText(bitacora.getObservacion());
        
        
        
        btnCrear.setEnabled(false);
        btnActualizar.setEnabled(true);
        this.pos = pos;
    }
    
    private void agregar(){
        try{
        
            if(txtFecha.getText().trim().equals("") || 
                txtAnotacion.getText().trim().equals("") || 
                txtObservacion.getText().trim().equals("")){
                JOptionPane.showMessageDialog( this, "Error: Verifique que los campos no esten vacios");
            }else{
                
                String fecha = txtFecha.getText();
                String anotacion = txtAnotacion.getText();
                String observacion = txtObservacion.getText();
               
                
                Bitacora bitacora = new Bitacora(anotacion,fecha, observacion);
                if(bitacoras==null){
                    bitacoras = new ArrayList<>();
                }
//                this.bitacoras.add(bitacora);
                gestionBitacora.AgregarBitacora(bitacora);
                Limpiar();
                JOptionPane.showMessageDialog( this, "Agregado correctamente");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog( this, "Error: "+ e.getMessage());
        }
    }
    
    private void editar(){
        try{
        
            if(txtFecha.getText().trim().equals("") || 
                txtAnotacion.getText().trim().equals("") || 
                txtObservacion.getText().trim().equals("")){
                JOptionPane.showMessageDialog( this, "Error: Verifique que los campos no esten vacios");
            }else{
                
                String fecha = txtFecha.getText();
                String anotacion = txtAnotacion.getText();
                String observacion = txtObservacion.getText();
               
                
                Bitacora bitacora = new Bitacora(anotacion,fecha, observacion);
                this.bitacoras.set(pos, bitacora);
                Limpiar();
                JOptionPane.showMessageDialog( this, "Editado correctamente");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog( this, "Error: "+ e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblNombreCaso = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtObservacion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtAnotacion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaBitacora = new javax.swing.JTable();
        btnActualizar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnCrear = new javax.swing.JButton();

        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        jPanel1.setBackground(new java.awt.Color(117, 169, 252));
        jPanel1.setLayout(null);

        lblNombreCaso.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblNombreCaso.setText("NombreClaveCaso");
        jPanel1.add(lblNombreCaso);
        lblNombreCaso.setBounds(210, 70, 160, 40);

        txtFecha.setEnabled(false);
        jPanel1.add(txtFecha);
        txtFecha.setBounds(90, 180, 190, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Observacion");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(340, 160, 120, 20);
        jPanel1.add(txtObservacion);
        txtObservacion.setBounds(340, 180, 190, 30);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Fecha");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(90, 160, 120, 20);
        jPanel1.add(txtAnotacion);
        txtAnotacion.setBounds(90, 240, 440, 30);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Anotacion");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(260, 210, 120, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("Bitacora");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(240, 10, 100, 40);

        jScrollPane1.setBackground(new java.awt.Color(20, 101, 245));

        tablaBitacora.setBackground(new java.awt.Color(20, 101, 245));
        tablaBitacora.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tablaBitacora.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaBitacoraMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaBitacora);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 380, 590, 290);

        btnActualizar.setBackground(new java.awt.Color(51, 51, 51));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.setToolTipText("");
        btnActualizar.setBorder(null);
        btnActualizar.setEnabled(false);
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizar);
        btnActualizar.setBounds(420, 300, 110, 40);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Atras");
        jButton1.setToolTipText("");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(10, 10, 70, 30);

        btnCrear.setBackground(new java.awt.Color(51, 51, 51));
        btnCrear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCrear.setForeground(new java.awt.Color(255, 255, 255));
        btnCrear.setText("Crear");
        btnCrear.setToolTipText("");
        btnCrear.setBorder(null);
        btnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearActionPerformed(evt);
            }
        });
        jPanel1.add(btnCrear);
        btnCrear.setBounds(90, 300, 320, 40);

        getContentPane().add(jPanel1);

        setSize(new java.awt.Dimension(629, 730));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        editar();
        ActualizarTabla();
        
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.hide();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
        agregar();
        ActualizarTabla();
    }//GEN-LAST:event_btnCrearActionPerformed

    private void tablaBitacoraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaBitacoraMouseClicked
        // TODO add your handling code here:
        Seleccion();
    }//GEN-LAST:event_tablaBitacoraMouseClicked
    
    private void cargarFechaInput(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        txtFecha.setText(dtf.format(LocalDateTime.now()));
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionBitacoras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionBitacoras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionBitacoras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionBitacoras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionBitacoras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNombreCaso;
    private javax.swing.JTable tablaBitacora;
    private javax.swing.JTextField txtAnotacion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtObservacion;
    // End of variables declaration//GEN-END:variables
}
