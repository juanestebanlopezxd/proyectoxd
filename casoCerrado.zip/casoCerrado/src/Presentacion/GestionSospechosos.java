/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;

import Modelo.Sospechoso;
import Persistencia.GestionSospechoso;
import java.awt.Image;
import static java.awt.Image.SCALE_SMOOTH;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class GestionSospechosos extends javax.swing.JFrame {
    
    GestionSospechoso gestionSospechoso = new GestionSospechoso();
    ArrayList<Sospechoso> sospechosos;
    DefaultTableModel modelo;
    int pos = 0;
    String ruta;
    /**
     * Creates new form GestionSospechoso
     */
    public GestionSospechosos() {
        initComponents();
        ActualizarTabla();
    }
    
    private void ActualizarTabla(){
        String[] fila;
        modelo = new DefaultTableModel();
        String[] columnas = {"Id","Alias","Nombre","Edad","UltDirec","Vivienda","Localidad","Ciudad","Departamento","Pais","Fotografia","Caracteristicas","",""};
        modelo.setColumnIdentifiers(columnas);
        sospechosos= gestionSospechoso.mostrarSospechoso();
        for(Sospechoso sospechoso:sospechosos){
            fila = new String[columnas.length];
            fila[0] = ""+sospechoso.getNumDeIdentidad();
            fila[1] = sospechoso.getAlias();
            fila[2] = sospechoso.getNombre();
            fila[3] = ""+sospechoso.getEdad();
            fila[4] = sospechoso.getUltiDireccion();
            fila[5] = ""+sospechoso.getNumDeVivienda();
            fila[6] = sospechoso.getLocalidad();
            fila[7] = sospechoso.getCiudad();
            fila[8] = sospechoso.getDepartamento();
            fila[9] = sospechoso.getPais();
            fila[10] = sospechoso.getFotografia();
            fila[11]= sospechoso.getCaractFisicas();    
            fila[12] = "Editar";
            fila[13] = "Eliminar";
            modelo.addRow(fila);
        }
        tablaSospechoso.setModel(modelo);
    }
    
    private void Limpiar(){
        
        txtEdad.setText("");
        txtId.setText("");
        txtCiudad.setText("");
        txtCaracteristicas.setText("");
        txtPais.setText("");
        txtLocalidad.setText("");
        txtAlias.setText("");
        txtDepartamento.setText("");
        txtUltimaDirec.setText("");
        txtNumVivienda.setText("");
        txtNombre.setText("");
        
        btnCrear.setEnabled(true);
        btnActualizar.setEnabled(false);
    }
    
    private void Seleccion(){
        if(tablaSospechoso.getSelectedColumn()==13){
             if (JOptionPane.showConfirmDialog(rootPane, "¿Seguro que desea eliminar?")==0) {
                gestionSospechoso.eliminarSospechoso(tablaSospechoso.getSelectedRow());
                Limpiar();
                ActualizarTabla();
            }
        }else if(tablaSospechoso.getSelectedColumn()==12){
             if (JOptionPane.showConfirmDialog(rootPane, "¿Seguro que desea editar?")==0) {
                editar(tablaSospechoso.getSelectedRow());
                ActualizarTabla();
            }
        }
    }
    private void editar(int pos){
        Sospechoso sospechoso = sospechosos.get(pos);
        txtId.setEnabled(false);
        
        txtId.setText(""+sospechoso.getNumDeIdentidad());
        txtEdad.setText(""+sospechoso.getEdad());
        txtCiudad.setText(sospechoso.getCiudad());
        txtCaracteristicas.setText(sospechoso.getCaractFisicas());
        txtPais.setText(sospechoso.getPais());
        txtLocalidad.setText(sospechoso.getLocalidad());
        txtAlias.setText(sospechoso.getAlias());
        txtDepartamento.setText(sospechoso.getDepartamento());
        txtUltimaDirec.setText(sospechoso.getUltiDireccion());
        txtNumVivienda.setText(""+sospechoso.getNumDeVivienda());
        txtNombre.setText(sospechoso.getNombre());
        
        
        btnCrear.setEnabled(false);
        btnActualizar.setEnabled(true);
        this.pos = pos;
    }
    
    private void agregar(){
        try{
        
            if(txtId.getText().trim().equals("") || 
                txtEdad.getText().trim().equals("") || 
                txtCiudad.getText().trim().equals("") || 
                txtCaracteristicas.getText().trim().equals("") || 
                txtPais.getText().trim().equals("") || 
                txtLocalidad.getText().trim().equals("") || 
                txtAlias.getText().trim().equals("") || 
                txtDepartamento.getText().trim().equals("") || 
                txtUltimaDirec.getText().trim().equals("") || 
                txtNumVivienda.getText().trim().equals("") || 
                txtNombre.getText().trim().equals("")
                    ){
                JOptionPane.showMessageDialog( this, "Error: Verifique que los campos no esten vacios");
            }else{
                long numDeIdentificacion = Long.parseLong(txtId.getText());
                int edad = Integer.parseInt(txtEdad.getText()) ;
                String ciudad = txtCiudad.getText();
                String caracteristicas = txtCaracteristicas.getText();
                String pais = txtPais.getText();
                String localidad = txtLocalidad.getText();
                String alias = txtAlias.getText();
                String departamento = txtDepartamento.getText();
                String direccion = txtUltimaDirec.getText();
                int vivienda = Integer.parseInt(txtNumVivienda.getText());
                String nombre = txtNombre.getText();
                
                Sospechoso sospechoso = new Sospechoso(numDeIdentificacion,nombre,
                        alias,edad,direccion,vivienda,localidad,ciudad,departamento,pais,ruta,caracteristicas);
                gestionSospechoso.AgregarSospechoso(sospechoso);
                Limpiar();
                JOptionPane.showMessageDialog( this, "Agregado correctamente");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog( this, "Error: "+ e.getMessage());
        }
    }
    
    private void editar(){
        try{
        
            if(txtId.getText().trim().equals("") || 
                txtEdad.getText().trim().equals("") || 
                txtCiudad.getText().trim().equals("") || 
                txtCaracteristicas.getText().trim().equals("") || 
                txtPais.getText().trim().equals("") || 
                txtLocalidad.getText().trim().equals("") || 
                txtAlias.getText().trim().equals("") || 
                txtDepartamento.getText().trim().equals("") || 
                txtUltimaDirec.getText().trim().equals("") || 
                txtNumVivienda.getText().trim().equals("") || 
                txtNombre.getText().trim().equals("")
                    ){
                JOptionPane.showMessageDialog( this, "Error: Verifique que los campos no esten vacios");
            }else{
                long numDeIdentificacion = Long.parseLong(txtId.getText());
                int edad = Integer.parseInt(txtEdad.getText()) ;
                String ciudad = txtCiudad.getText();
                String caracteristicas = txtCaracteristicas.getText();
                String pais = txtPais.getText();
                String localidad = txtLocalidad.getText();
                String alias = txtAlias.getText();
                String departamento = txtDepartamento.getText();
                String direccion = txtUltimaDirec.getText();
                int vivienda = Integer.parseInt(txtNumVivienda.getText());
                String nombre = txtNombre.getText();
                
                Sospechoso sospechoso = new Sospechoso(numDeIdentificacion,nombre,
                        alias,edad,direccion,vivienda,localidad,ciudad,departamento,pais,ruta,caracteristicas);
                gestionSospechoso.editarSospechoso(pos,sospechoso);
                Limpiar();
                JOptionPane.showMessageDialog( this, "Editado correctamente");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog( this, "Error: "+ e.getMessage());
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtAlias = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtUltimaDirec = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtLocalidad = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtNumVivienda = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtCiudad = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtDepartamento = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtPais = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtCaracteristicas = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        lblFotografia = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaSospechoso = new javax.swing.JTable();
        btnCrear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane2.setAlignmentX(0);
        jScrollPane2.setAlignmentY(0);
        jScrollPane2.setAutoscrolls(true);

        jPanel1.setBackground(new java.awt.Color(117, 169, 252));
        jPanel1.setAutoscrolls(true);
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Gestion sospechoso");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(310, 10, 230, 40);
        jPanel1.add(txtId);
        txtId.setBounds(200, 230, 190, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Identificacion");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(200, 210, 120, 20);
        jPanel1.add(txtAlias);
        txtAlias.setBounds(200, 290, 190, 30);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Alias");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(200, 270, 120, 20);
        jPanel1.add(txtUltimaDirec);
        txtUltimaDirec.setBounds(200, 350, 190, 30);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Ultima direccion");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(200, 330, 120, 20);
        jPanel1.add(txtLocalidad);
        txtLocalidad.setBounds(200, 420, 190, 30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Localidad");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(200, 400, 120, 20);
        jPanel1.add(txtNombre);
        txtNombre.setBounds(450, 230, 190, 30);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Nombre");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(450, 210, 120, 20);
        jPanel1.add(txtEdad);
        txtEdad.setBounds(450, 290, 190, 30);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Edad");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(450, 270, 120, 20);
        jPanel1.add(txtNumVivienda);
        txtNumVivienda.setBounds(450, 350, 190, 30);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("N° de vivienda");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(450, 330, 120, 20);
        jPanel1.add(txtCiudad);
        txtCiudad.setBounds(450, 420, 190, 30);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Ciudad");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(450, 400, 120, 20);
        jPanel1.add(txtDepartamento);
        txtDepartamento.setBounds(200, 480, 190, 30);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Departamento");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(200, 460, 120, 20);
        jPanel1.add(txtPais);
        txtPais.setBounds(450, 480, 190, 30);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Pais");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(450, 460, 120, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Caracteristicas");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(450, 520, 120, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("+");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel12);
        jLabel12.setBounds(470, 140, 34, 40);
        jPanel1.add(txtCaracteristicas);
        txtCaracteristicas.setBounds(450, 540, 190, 30);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/rect31.png"))); // NOI18N
        jLabel14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(jLabel14);
        jLabel14.setBounds(350, 60, 140, 140);

        lblFotografia.setIcon(new javax.swing.ImageIcon("C:\\Users\\Antony\\Pictures\\zucuna.jpg")); // NOI18N
        lblFotografia.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(lblFotografia);
        lblFotografia.setBounds(350, 60, 140, 140);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Atras");
        jButton1.setToolTipText("");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(10, 10, 70, 30);

        btnActualizar.setBackground(new java.awt.Color(51, 51, 51));
        btnActualizar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnActualizar.setText("Actualizar");
        btnActualizar.setToolTipText("");
        btnActualizar.setBorder(null);
        btnActualizar.setEnabled(false);
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizar);
        btnActualizar.setBounds(520, 590, 120, 40);

        tablaSospechoso.setBackground(new java.awt.Color(20, 101, 245));
        tablaSospechoso.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10", "Title 11", "Title 12", "Title 13"
            }
        ));
        tablaSospechoso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaSospechosoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaSospechoso);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 640, 790, 180);

        btnCrear.setBackground(new java.awt.Color(51, 51, 51));
        btnCrear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCrear.setForeground(new java.awt.Color(255, 255, 255));
        btnCrear.setText("Crear");
        btnCrear.setToolTipText("");
        btnCrear.setBorder(null);
        btnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearActionPerformed(evt);
            }
        });
        jPanel1.add(btnCrear);
        btnCrear.setBounds(200, 590, 300, 40);

        jScrollPane2.setViewportView(jPanel1);

        getContentPane().add(jScrollPane2);

        setSize(new java.awt.Dimension(829, 899));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new Gestion().setVisible(true);
        this.hide();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        // TODO add your handling code here:
        editar();
        ActualizarTabla();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.showOpenDialog(fileChooser);
        try {
            ruta = fileChooser.getSelectedFile().getAbsolutePath();
            ImageIcon imageIcon = new ImageIcon(new ImageIcon(ruta).getImage().getScaledInstance(140, 140, Image.SCALE_DEFAULT));
            lblFotografia.setIcon(imageIcon);
        } catch(Exception e){   
        }
    }//GEN-LAST:event_jLabel12MouseClicked

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
        agregar();
        ActualizarTabla();
    }//GEN-LAST:event_btnCrearActionPerformed

    private void tablaSospechosoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaSospechosoMouseClicked
        // TODO add your handling code here:
        Seleccion();
    }//GEN-LAST:event_tablaSospechosoMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionSospechosos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionSospechosos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionSospechosos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionSospechosos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionSospechosos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblFotografia;
    private javax.swing.JTable tablaSospechoso;
    private javax.swing.JTextField txtAlias;
    private javax.swing.JTextField txtCaracteristicas;
    private javax.swing.JTextField txtCiudad;
    private javax.swing.JTextField txtDepartamento;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLocalidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumVivienda;
    private javax.swing.JTextField txtPais;
    private javax.swing.JTextField txtUltimaDirec;
    // End of variables declaration//GEN-END:variables
}
