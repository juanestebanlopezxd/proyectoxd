/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Presentacion;

import Modelo.Caso;
import Modelo.Detective;
import Modelo.Sospechoso;
import Modelo.Bitacora;
import Persistencia.GestionCaso;
import Persistencia.GestionDetective;
import Persistencia.GestionSospechoso;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Antony
 */
public class GestionCasos extends javax.swing.JFrame {

    private GestionDetective gestionDetectives;
    private GestionSospechoso gestionSospechoso;
    private ArrayList<Sospechoso> sospechosos;
    private ArrayList<Detective> detectives;
    private GestionCaso gestionCaso;
    GestionBitacoras gestionBitacoras;
    ArrayList<Bitacora> bitacoras;
    int pos;
    public GestionCasos() {
        initComponents();
        gestionDetectives = new GestionDetective();
        gestionSospechoso = new GestionSospechoso();
        gestionBitacoras = new GestionBitacoras();
        sospechosos = gestionSospechoso.mostrarSospechoso();
        detectives = gestionDetectives.mostrarDetective();
        gestionCaso = new GestionCaso();
        CargarSospechosos();
        ActualizarTabla();
    }
    
    private void CargarSospechosos(){
        comboSospechoso.removeAllItems();
        comboSospechoso.addItem("Seleccione");
        for(Sospechoso sospechoso: sospechosos){
            comboSospechoso.addItem(sospechoso.getNombre());
        }
    }
    private void ActualizarTabla(){
        String[] fila;
        DefaultTableModel modelo = new DefaultTableModel();
        String[] columnas = {"numCaso","prioridad","descripcion","Nombre clave","Tipo","Detective","Sospechoso","",""};
        modelo.setColumnIdentifiers(columnas);
        ArrayList<Caso> casos = gestionCaso.mostrarCasos();
        for(Caso caso:casos){
            fila = new String[columnas.length];
            fila[0] = ""+caso.getNumeroCaso();
            fila[1] = caso.getCodigoDePrioridad();
            fila[2] = caso.getDescripCaso();
            fila[3] = caso.getNombClave();
            fila[4] = caso.getTipocaso();
            fila[5] = caso.getDetective().getNombreClave();
            fila[6] = caso.getSospechoso().getNombre();
            fila[7] = "Editar";
            fila[8] = "Eliminar";
            modelo.addRow(fila);
        }
        tblCasos.setModel(modelo);
    }
    private Caso ObtenerCaso(){
       
        bitacoras =  gestionBitacoras.bitacoras;
        int numCaso = Integer.parseInt(txtCaso.getText());
        String prioridad = comboPrio.getSelectedItem().toString();
        String descripcion = txtDescripcion.getText();
        String nombreClave = txtNombreClave.getText();
        Sospechoso sospechoso = sospechosos.get(comboSospechoso.getSelectedIndex()-1);
        Detective detective = detectives.get(comboDetective.getSelectedIndex()-1);
        //Detective detective2 = detectives.get(comboSegundoDetective.getSelectedIndex()-1);
        String tipo = comboTipo.getSelectedItem().toString();
        String alcance = comboAlcance.getSelectedItem().toString();
        String linea = txtCibercrimen.getText();

        return new Caso(numCaso, descripcion, prioridad, nombreClave, tipo, detective, bitacoras, sospechoso);
             
    }
    private void Limpiar(){
        txtCaso.setText("");
        txtDescripcion.setText("");
        txtNombreClave.setText("");
        txtCibercrimen.setText("");
        comboPrio.setSelectedIndex(0);
        comboSospechoso.setSelectedIndex(0);
        comboDetective.setSelectedIndex(0);
        comboTipo.setSelectedIndex(0);
        comboAlcance.setSelectedIndex(0);
        comboSegundoDetective.setSelectedIndex(0);
        txtCaso.setEnabled(true);
        jButton3.setEnabled(false);
        jButton2.setEnabled(true);
        
    }
    private void seleccionar(){
        if(tblCasos.getSelectedRow()>=0){
            if(tblCasos.getSelectedColumn()==7){
                txtCaso.setEnabled(false);
                jButton3.setEnabled(true);
                jButton2.setEnabled(false);
                this.pos = tblCasos.getSelectedRow();
                Caso caso = gestionCaso.mostrarCasos().get(pos);
                txtCaso.setText(""+caso.getNumeroCaso());
                txtDescripcion.setText(caso.getDescripCaso());
                txtNombreClave.setText(caso.getNombClave());
                comboPrio.setSelectedItem(caso.getCodigoDePrioridad());
                comboSospechoso.setSelectedItem(caso.getSospechoso().getNombre());
                comboDetective.setSelectedItem(caso.getDetective().getNombreClave());
                comboTipo.setSelectedItem(caso.getTipocaso());     
                gestionBitacoras.bitacoras = caso.getBitacora();
            }else if(tblCasos.getSelectedColumn()==8){
                if(JOptionPane.showConfirmDialog(rootPane, "¿Quiere eliminar?")==0){
                    this.gestionCaso.EliminarCaso(pos);
                    ActualizarTabla();
                }
                
            }
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtCaso = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNombreClave = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        comboPrio = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        comboDetective = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        comboSospechoso = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        comboTipo = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCasos = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        txtCibercrimen = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        comboSegundoDetective = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        comboAlcance = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txtDescripcion = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(117, 169, 252));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Gestion caso");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(230, 30, 160, 40);
        jPanel1.add(txtCaso);
        txtCaso.setBounds(100, 130, 190, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Numero del caso");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(100, 110, 120, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Detective");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(100, 290, 180, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Codigo de prioridad");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(100, 170, 140, 20);

        txtNombreClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClaveActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombreClave);
        txtNombreClave.setBounds(100, 250, 190, 30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Nombre clave");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(100, 230, 180, 20);

        comboPrio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "A", "B", "C" }));
        comboPrio.setToolTipText("");
        comboPrio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboPrioActionPerformed(evt);
            }
        });
        jPanel1.add(comboPrio);
        comboPrio.setBounds(100, 190, 190, 22);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Atras");
        jButton1.setToolTipText("");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(10, 10, 70, 30);

        comboDetective.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione" }));
        jPanel1.add(comboDetective);
        comboDetective.setBounds(100, 310, 190, 22);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Descripcion");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(320, 110, 110, 20);

        comboSospechoso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboSospechoso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboSospechosoActionPerformed(evt);
            }
        });
        jPanel1.add(comboSospechoso);
        comboSospechoso.setBounds(320, 250, 200, 22);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Sospechoso");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(320, 230, 110, 20);

        comboTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Cibercrimen", "Homicidios", "Narcoticos" }));
        comboTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTipoActionPerformed(evt);
            }
        });
        jPanel1.add(comboTipo);
        comboTipo.setBounds(320, 310, 200, 22);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Tipo");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(320, 290, 180, 20);

        tblCasos.setBackground(new java.awt.Color(20, 101, 245));
        tblCasos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10", "Title 11", "Title 12", "Title 13"
            }
        ));
        tblCasos.setGridColor(new java.awt.Color(211, 211, 211));
        tblCasos.setRowSelectionAllowed(false);
        tblCasos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCasosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCasos);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(60, 520, 510, 150);

        jButton2.setBackground(new java.awt.Color(51, 51, 51));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Crear");
        jButton2.setToolTipText("");
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(100, 460, 290, 40);

        txtCibercrimen.setEnabled(false);
        txtCibercrimen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCibercrimenActionPerformed(evt);
            }
        });
        jPanel1.add(txtCibercrimen);
        txtCibercrimen.setBounds(100, 410, 420, 30);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Linea de cibercrimen");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(100, 390, 180, 20);

        comboSegundoDetective.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboSegundoDetective.setEnabled(false);
        jPanel1.add(comboSegundoDetective);
        comboSegundoDetective.setBounds(320, 360, 200, 22);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("2do Detective");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(320, 340, 190, 20);

        comboAlcance.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "local", "estatal", "federal" }));
        comboAlcance.setEnabled(false);
        jPanel1.add(comboAlcance);
        comboAlcance.setBounds(100, 360, 190, 22);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("Alcance");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(100, 340, 180, 20);

        jButton3.setText("Editar");
        jButton3.setEnabled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(400, 460, 120, 40);

        jButton4.setText("Bitacoras");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(320, 180, 200, 30);
        jPanel1.add(txtDescripcion);
        txtDescripcion.setBounds(320, 130, 200, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 613, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 722, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(629, 730));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new Gestion().setVisible(true);
        this.hide();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Caso caso = ObtenerCaso();
        gestionCaso.AgregarCaso(caso);
        JOptionPane.showMessageDialog( this, "Agregado correctamente");
        ActualizarTabla();
        Limpiar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void comboPrioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboPrioActionPerformed
        comboDetective.removeAllItems();
        comboDetective.addItem("Seleccione");
        if(comboPrio.getSelectedItem().equals("Seleccione")){
        }else if(comboPrio.getSelectedItem().equals("A")){
            for(Detective d : detectives){
                if(d.getAñosDeExperiencia()<3){
                    comboDetective.addItem(d.getNombreClave());
                }
            }
        }else if(comboPrio.getSelectedItem().equals("B")){
            for(Detective d : detectives){
                if(d.getAñosDeExperiencia()>=3 && d.getAñosDeExperiencia()<5){
                    comboDetective.addItem(d.getNombreClave());
                }
            }
        }else{
            for(Detective d : detectives){
                if(d.getAñosDeExperiencia()>=5){
                    comboDetective.addItem(d.getNombreClave());
                }
            }
        }
    }//GEN-LAST:event_comboPrioActionPerformed

    private void comboTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTipoActionPerformed
        if(comboTipo.getSelectedItem().equals("Seleccione")){
            comboAlcance.setEnabled(false);
            comboAlcance.setSelectedIndex(0);
            comboSegundoDetective.setEnabled(false);
            comboSegundoDetective.setSelectedIndex(0);
            txtCibercrimen.setEnabled(false);
            txtCibercrimen.setText("");
        }else if(comboTipo.getSelectedItem().equals("Cibercrimen")){
            txtCibercrimen.setEnabled(true);
            comboAlcance.setEnabled(false);
            comboAlcance.setSelectedIndex(0);
            comboSegundoDetective.setEnabled(false);
            comboSegundoDetective.setSelectedIndex(0);
        }else if(comboTipo.getSelectedItem().equals("Homicidios")){
            comboSegundoDetective.setEnabled(true);
            txtCibercrimen.setEnabled(false);
            txtCibercrimen.setText("");
            comboAlcance.setEnabled(false);
            comboAlcance.setSelectedIndex(0);
            comboSegundoDetective.removeAllItems();
            comboSegundoDetective.addItem("Seleccione");
            if(comboPrio.getSelectedItem().equals("Seleccione")){
            }else if(comboPrio.getSelectedItem().equals("A")){
                for(Detective d : detectives){
                    if(d.getAñosDeExperiencia()<3){
                        comboSegundoDetective.addItem(d.getNombreClave());
                    }
                }
            }else if(comboPrio.getSelectedItem().equals("B")){
                for(Detective d : detectives){
                    if(d.getAñosDeExperiencia()>=3 && d.getAñosDeExperiencia()<5){
                        comboSegundoDetective.addItem(d.getNombreClave());
                    }
                }
            }else{
                for(Detective d : detectives){
                    if(d.getAñosDeExperiencia()>=5){
                        comboSegundoDetective.addItem(d.getNombreClave());
                    }
                }
            }
        }else{
            comboAlcance.setEnabled(true);
            comboSegundoDetective.setEnabled(false);
            comboSegundoDetective.setSelectedIndex(0);
            txtCibercrimen.setEnabled(false);
            txtCibercrimen.setText("");
        }
    }//GEN-LAST:event_comboTipoActionPerformed

    private void txtCibercrimenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCibercrimenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCibercrimenActionPerformed

    private void comboSospechosoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboSospechosoActionPerformed
        if(comboTipo.getSelectedIndex()==2){
            
        }
    }//GEN-LAST:event_comboSospechosoActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Caso c = ObtenerCaso();
        gestionCaso.EditarCaso(c, pos);
        Limpiar();
        ActualizarTabla();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        gestionBitacoras.ponerTitulo(txtNombreClave.getText());
        gestionBitacoras.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void tblCasosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCasosMouseClicked
        seleccionar();
    }//GEN-LAST:event_tblCasosMouseClicked

    private void txtNombreClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClaveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClaveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionCasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionCasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionCasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionCasos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionCasos().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboAlcance;
    private javax.swing.JComboBox<String> comboDetective;
    private javax.swing.JComboBox<String> comboPrio;
    private javax.swing.JComboBox<String> comboSegundoDetective;
    private javax.swing.JComboBox<String> comboSospechoso;
    private javax.swing.JComboBox<String> comboTipo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCasos;
    private javax.swing.JTextField txtCaso;
    private javax.swing.JTextField txtCibercrimen;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtNombreClave;
    // End of variables declaration//GEN-END:variables
}
