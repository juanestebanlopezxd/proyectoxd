
package Persistencia;

import Modelo.Detective;
import java.util.ArrayList;


public class GestionDetective {
    GestionArchivo archivo;
    ArrayList<Detective> detectives;
    String ruta ="detective.p";
    
    public GestionDetective() {
        archivo = new GestionArchivo();
        detectives = mostrarDetective();
    }
    
    public void AgregarDetective(Detective detective ) throws Exception{
        boolean agregar = true;
        for(Detective item : detectives){
            if(item.getNumDeIdentificacion()== detective.getNumDeIdentificacion()){
                agregar = false;
                throw new Exception("No se puede agregar repetido");
            }
        }
        if(agregar){
            detectives.add(detective);
            archivo.agregar(detectives, ruta);
            detectives = mostrarDetective();
        }
    }
    public ArrayList<Detective> mostrarDetective(){
        return archivo.obtener(ruta);
    }
    
    
    public void eliminarDetective(int pos){
        detectives = mostrarDetective();
        detectives.remove(pos);
        archivo.agregar(detectives, ruta);
    }
    
    public boolean editarDetective(int pos,Detective detective){
        detectives.get(pos).setNombreClave(detective.getNombreClave());
        detectives.get(pos).setNombre(detective.getNombre());
        detectives.get(pos).setApellido(detective.getApellido());
        detectives.get(pos).setAñosDeExperiencia(detective.getAñosDeExperiencia());
        archivo.agregar(detectives, ruta);
        return false;
    }
    
    
    
    
    
    
}
