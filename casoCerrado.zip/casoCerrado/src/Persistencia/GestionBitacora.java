
package Persistencia;

import Modelo.Bitacora;
import java.util.ArrayList;


public class GestionBitacora {
    ArrayList<Bitacora> bitacoras;
    GestionArchivo archivo;
    String ruta ="bitacora.p";
    
    public GestionBitacora(){
        archivo = new GestionArchivo();
        bitacoras = mostrarBitacora();
    }
    
    public ArrayList<Bitacora> mostrarBitacora(){
        return archivo.obtener(ruta);
    }
    
    public void AgregarBitacora(Bitacora bitacora ) throws Exception{
        
        bitacoras.add(bitacora);
        archivo.agregar(bitacoras, ruta);
        bitacoras = mostrarBitacora();
        
    }
    
    public void eliminarBitacora(int pos){
        bitacoras = mostrarBitacora();
        bitacoras.remove(pos);
        archivo.agregar(bitacoras, ruta);
    }
    
    public boolean editarBitacora(int pos,Bitacora bitacora){
        bitacoras.get(pos).setFechaDeRegistro(bitacora.getFechaDeRegistro());
        bitacoras.get(pos).setObservacion(bitacora.getObservacion());
        bitacoras.get(pos).setAnotaciones(bitacora.getAnotaciones());
        
        archivo.agregar(bitacoras, ruta);
        return false;
    }
    
    
}
