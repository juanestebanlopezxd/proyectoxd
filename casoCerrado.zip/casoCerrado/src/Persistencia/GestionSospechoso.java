
package Persistencia;

import Modelo.Sospechoso;
import java.util.ArrayList;


public class GestionSospechoso {
    GestionArchivo archivo;
    ArrayList<Sospechoso> sospechosos;
    String ruta ="sospechoso.p";

    public GestionSospechoso() {
        archivo = new GestionArchivo();
        sospechosos = mostrarSospechoso();
    }
    
    public ArrayList<Sospechoso> mostrarSospechoso(){
        return archivo.obtener(ruta);
    }
    public void AgregarSospechoso(Sospechoso sospechoso ) throws Exception{
        boolean agregar = true;
        for(Sospechoso item : sospechosos){
            if(item.getNumDeIdentidad()== sospechoso.getNumDeIdentidad()){
                agregar = false;
                throw new Exception("No se puede agregar repetido");
            }
        }
        if(agregar){
            sospechosos.add(sospechoso);
            archivo.agregar(sospechosos, ruta);
            sospechosos = mostrarSospechoso();
        }
    }
    
    public void eliminarSospechoso(int pos){
        sospechosos = mostrarSospechoso();
        sospechosos.remove(pos);
        archivo.agregar(sospechosos, ruta);
    }
    
    public boolean editarSospechoso(int pos,Sospechoso sospechoso){
        sospechosos.get(pos).setAlias(sospechoso.getAlias());
        sospechosos.get(pos).setNombre(sospechoso.getNombre());
        sospechosos.get(pos).setEdad(sospechoso.getEdad());
        sospechosos.get(pos).setUltiDireccion(sospechoso.getUltiDireccion());
        sospechosos.get(pos).setNumDeVivienda(sospechoso.getNumDeVivienda());
        sospechosos.get(pos).setLocalidad(sospechoso.getLocalidad());
        sospechosos.get(pos).setCiudad(sospechoso.getCiudad());
        sospechosos.get(pos).setDepartamento(sospechoso.getDepartamento());
        sospechosos.get(pos).setPais(sospechoso.getPais());
        sospechosos.get(pos).setFotografia(sospechoso.getFotografia());
        sospechosos.get(pos).setCaractFisicas(sospechoso.getCaractFisicas());
        
        archivo.agregar(sospechosos, ruta);
        return false;
    }
    
}
