/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import Modelo.Caso;
import java.util.ArrayList;

/**
 *
 * @author JUAN ESTEBAN
 */
public class GestionCaso {
    ArrayList<Caso> casos;
    GestionArchivo archivo;
    String ruta ="casos.p";
    public GestionCaso(){
        
        archivo = new GestionArchivo();
        casos = mostrarCasos();
    }
    
    public void AgregarCaso(Caso caso){
        boolean agregar = true;
        for(Caso item : casos){
            if(item.getNumeroCaso() == caso.getNumeroCaso()){
                agregar = false;
            }
        }
        if(agregar){
            casos.add(caso);
            archivo.agregar(casos, ruta);
            casos = mostrarCasos();
        }
    }
    
    public ArrayList<Caso> mostrarCasos(){
        return archivo.obtener(ruta);
    }
    
    public void EditarCaso(Caso caso, int pos){
        this.casos.set(pos, caso);
        archivo.agregar(casos, ruta);
        casos = mostrarCasos();
    }
    public void EliminarCaso(int pos){
        this.casos.remove(pos);
        archivo.agregar(casos, ruta);
        casos = mostrarCasos();
    }
    
    
    
}
