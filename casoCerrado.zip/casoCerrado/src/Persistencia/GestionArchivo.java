
package Persistencia;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class GestionArchivo {
    
    public void agregar(ArrayList object,String ruta){
        ObjectOutputStream escritor = null;
        try {
            escritor = new ObjectOutputStream(new FileOutputStream(ruta));
            escritor.writeObject(object);
        } catch (IOException ex) {
        } finally {
            try {
                if (escritor != null) {
                    escritor.close();
                }
            } catch (IOException err) {
            }
        }
    }
    
    public ArrayList obtener(String ruta){
        ArrayList lista = new ArrayList<>();
        ObjectInputStream lector = null;
        try {
            lector = new ObjectInputStream(new FileInputStream(ruta));
            lista = (ArrayList) lector.readObject();
        } catch (Exception ex) {
            System.out.println(ex);
        } finally {
            try {
                if (lector != null) {
                    lector.close();
                }
            } catch (Exception err) {
            }
        }
        return lista;
    }
    
}
