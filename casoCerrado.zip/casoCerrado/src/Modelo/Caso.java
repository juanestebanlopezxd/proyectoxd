/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author JUAN ESTEBAN
 */
public class Caso implements Serializable{

    public ArrayList<Bitacora> getBitacora() {
        return bitacoras;
    }

    public void setBitacora(ArrayList<Bitacora> bitacora) {
        this.bitacoras = bitacora;
    }

    public Sospechoso getSospechoso() {
        return sospechoso;
    }

    public void setSospechoso(Sospechoso sospechoso) {
        this.sospechoso = sospechoso;
    }
    private int numeroCaso;
    private String descripCaso;
    private String codigoDePrioridad;
    private String nombClave;
    private String tipocaso;

    private  Detective detective;
    private ArrayList<Bitacora> bitacoras;
    private Sospechoso sospechoso;
    
    public String getTipocaso() {
        return tipocaso;
    }

    public void setTipocaso(String tipocaso) {
        this.tipocaso = tipocaso;
    }
    

    public Caso(int numeroCaso, String descripCaso, String codigoDePrioridad, String nombClave) {
        this.numeroCaso = numeroCaso;
        this.descripCaso = descripCaso;
        this.codigoDePrioridad = codigoDePrioridad;
        this.nombClave = nombClave;

    }

    public Caso(int numeroCaso, String descripCaso, String codigoDePrioridad, String nombClave, String tipocaso, Detective detective, ArrayList<Bitacora> bitacora, Sospechoso sospechoso) {
        this.numeroCaso = numeroCaso;
        this.descripCaso = descripCaso;
        this.codigoDePrioridad = codigoDePrioridad;
        this.nombClave = nombClave;
        this.tipocaso = tipocaso;
        this.detective = detective;
        this.bitacoras = bitacoras;
        this.sospechoso = sospechoso;
    }
    public Caso(int numeroCaso, String descripCaso, String codigoDePrioridad, String nombClave, String tipocaso, Detective detective, Sospechoso sospechoso) {
        this.numeroCaso = numeroCaso;
        this.descripCaso = descripCaso;
        this.codigoDePrioridad = codigoDePrioridad;
        this.nombClave = nombClave;
        this.tipocaso = tipocaso;
        this.detective = detective;
        this.sospechoso = sospechoso;
    }
    
    

    public Caso() {
        this.bitacoras=new ArrayList<Bitacora>();
        this.sospechoso=new Sospechoso();
    }

    /**
     * @return the numeroCaso
     */
    public int getNumeroCaso() {
        return numeroCaso;
    }

    /**
     * @param numeroCaso the numeroCaso to set
     */
    public void setNumeroCaso(int numeroCaso) {
        this.numeroCaso = numeroCaso;
    }

    /**
     * @return the descripCaso
     */
    public String getDescripCaso() {
        return descripCaso;
    }

    /**
     * @param descripCaso the descripCaso to set
     */
    public void setDescripCaso(String descripCaso) {
        this.descripCaso = descripCaso;
    }

    /**
     * @return the codigoDePrioridad
     */
    public String getCodigoDePrioridad() {
        return codigoDePrioridad;
    }

    /**
     * @param codigoDePrioridad the codigoDePrioridad to set
     */
    public void setCodigoDePrioridad(String codigoDePrioridad) {
        this.codigoDePrioridad = codigoDePrioridad;
    }

    /**
     * @return the nombClave
     */
    public String getNombClave() {
        return nombClave;
    }

    /**
     * @param nombClave the nombClave to set
     */
    public void setNombClave(String nombClave) {
        this.nombClave = nombClave;
    }

    /**
     * @return the detective
     */
    public Detective getDetective() {
        return detective;
    }

    /**
     * @param detective the detective to set
     */
    public void setDetective(Detective detective) {
        this.detective = detective;
    }
    
    
}
